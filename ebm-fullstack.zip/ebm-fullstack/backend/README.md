# Backend: deploy to Render or Railway

Set the following environment variables:
- MONGO_URI
- PAYSTACK_SECRET_KEY
