# EBM Shoes Fullstack Project
Includes customer-facing frontend, admin dashboard, and backend API